"""
Example sentences to test spaCy and its language models.

>>> from spacy.lang.ca.examples import sentences
>>> docs = nlp.pipe(sentences)
"""


sentences = [
    "Apple està buscant comprar una startup del Regne Unit per mil milions de dòlars",
    "Els cotxes autònoms deleguen la responsabilitat de l'assegurança als seus fabricants",
    "San Francisco analitza prohibir els robots de repartiment",
    "Londres és una gran ciutat del Regne Unit",
    "El gat menja peix",
    "Veig a l'home amb el telescopi",
    "L'aranya menja mosques",
    "El pingüí incuba en el seu niu",
]
